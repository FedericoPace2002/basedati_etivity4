from config import Session
from models import Cliente

session = Session()

id_cliente = int(input("Inserisci l'ID del cliente da eliminare: "))
cliente = session.query(Cliente).filter_by(IDCliente=id_cliente).first()

if cliente:
    try:
        session.delete(cliente)
        session.commit()
        print("Cliente cancellato.")
    except Exception as e:
        session.rollback()
        print("Errore durante la cancellazione:", e)
else:
    print("Cliente non trovato.")

