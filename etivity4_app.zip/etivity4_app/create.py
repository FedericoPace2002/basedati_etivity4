from config import Session
from models import Cliente

session = Session()

# Input utente
id_cliente = int(input("Inserisci l'ID del cliente: "))
ragione_sociale = input("Inserisci la Ragione Sociale: ")
email = input("Inserisci l'Email: ")

# Verifica se l'ID esiste già
cliente_esistente = session.query(Cliente).filter_by(IDCliente=id_cliente).first()

if cliente_esistente:
    print("Errore: Cliente già presente con questo ID.")
else:
    nuovo_cliente = Cliente(IDCliente=id_cliente, RagioneSociale=ragione_sociale, Email=email)
    session.add(nuovo_cliente)
    session.commit()
    print("Cliente inserito correttamente.")
