from config import Session
from models import Cliente

session = Session()

# Selezione ID
id_cliente = int(input("Inserisci l'ID del cliente da aggiornare: "))
cliente = session.query(Cliente).filter_by(IDCliente=id_cliente).first()

if cliente:
    scelta = input("Vuoi aggiornare 'email' o 'ragione sociale'? ").strip().lower()
    if scelta == 'email':
        nuova_email = input("Inserisci la nuova email: ")
        cliente.Email = nuova_email
    elif scelta == 'ragione sociale':
        nuova_rs = input("Inserisci la nuova ragione sociale: ")
        cliente.RagioneSociale = nuova_rs
    else:
        print("Campo non valido.")
    session.commit()
    print("Cliente aggiornato.")
else:
    print("Cliente non trovato.")
