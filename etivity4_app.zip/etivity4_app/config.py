from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "mysql+mysqlconnector://root:Federico2002*@localhost/serviceups?auth_plugin=mysql_native_password"

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
