from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String

Base = declarative_base()

class Cliente(Base):
    __tablename__ = 'cliente'
    IDCliente = Column(Integer, primary_key=True)
    RagioneSociale = Column(String(100))
    Email = Column(String(100))
