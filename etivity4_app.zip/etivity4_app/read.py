from config import Session
from models import Cliente

session = Session()
clienti = session.query(Cliente).all()
for c in clienti:
    print(c.IDCliente, c.RagioneSociale, c.Email)
