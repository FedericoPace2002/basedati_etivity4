## Etivity 4 - CRUD Application con SQLAlchemy

Questo progetto è stato realizzato per l'e-tivity 4 del corso di Basi di Dati.  
Consiste nello sviluppo di un'applicazione Python che consente di eseguire operazioni CRUD su un database MySQL, utilizzando SQLAlchemy come ORM.

## Requisiti

- Python 3.x
- MySQL 8.0+
- Librerie Python (vedi requirements.txt)

## Struttura del progetto

etivity4_app/
├── config.py            # Connessione al database
├── models.py            # Modello ORM (definizione delle tabelle)
├── setup_db.py          # Creazione delle tabelle nel database
├── create.py            # Inserimento di nuovi clienti
├── read.py              # Lettura e visualizzazione dei clienti
├── update.py            # Modifica dati cliente
├── delete.py            # Cancellazione cliente
├── requirements.txt     # Dipendenze del progetto

## Autore

Federico Pace
Università Niccolò Cusano (IN08000519)
Corso: Basi di Dati
