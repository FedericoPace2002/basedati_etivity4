from config import engine
from models import Base

Base.metadata.create_all(engine)
print("Tabelle create correttamente.")
